import { useState, useEffect, useCallback, useMemo } from 'react';
import { supabase, TABLES } from '@/integrations/supabase';
import { isValidBranchId } from '@/shared/utils/safeIds';
import { cashService } from '../services/cashService';
import {
	isManualLocalExpense,
	isCashWithdrawal,
	isOperatingLocalExpense,
	EXPENSE_KIND_CASH_WITHDRAWAL,
	EXPENSE_KIND_OPERATING,
} from '../utils/cashMovementKinds';
import { getExpectedByMethod } from '../utils/shiftCloseReconciliation';
import { getCashMovementPaymentMethod } from '@/shared/utils/orderUtils';

export const useCashSystem = (showNotify, branchId) => {
    const [activeShift, setActiveShift] = useState(null);
    const [loading, setLoading] = useState(true);
    const [movements, setMovements] = useState([]);
    const [loadingMovements, setLoadingMovements] = useState(false);

    /**
     * Carga los movimientos de un turno específico
     */
    const loadMovements = useCallback(async (shiftId) => {
        setLoadingMovements(true);
        try {
            const data = await cashService.getShiftMovements(shiftId);
            setMovements(data || []);
        } catch {
            setMovements([]);
        } finally {
            setLoadingMovements(false);
        }
    }, []);

    /**
     * Carga el turno activo para la sucursal seleccionada
     */
    const loadActiveShift = useCallback(async () => {
        if (!branchId || branchId === 'all' || !isValidBranchId(branchId)) {
            // [ROBUSTEZ] No llamar API con slug (ej. "san-joaquin") → evita 400 y caja que no carga
            setActiveShift(null);
            setMovements([]);
            setLoading(false);
            return;
        }

        setLoading(true);
        try {
            const { data: shift, error } = await supabase
                .from(TABLES.cash_shifts)
                .select(`*, ${TABLES.cash_movements}(count)`)
                .eq('status', 'open')
                .eq('branch_id', branchId) // FILTRO CRÍTICO POR SUCURSAL
                .maybeSingle();

            if (error) throw error;

            // [FIX] Actualizar si cambia el ID o el balance esperado (para reflejar ingresos/egresos)
            setActiveShift(prev => {
                if (!prev || !shift) return shift;
                // Usamos Number() para asegurar comparación por valor numérico y no por referencia o tipo (string vs number)
                if (prev.id === shift.id && Number(prev.expected_balance) === Number(shift.expected_balance)) return prev;
                return shift;
            });
            
            if (shift) {
                loadMovements(shift.id);
            } else {
                setMovements([]);
            }
        } catch {
            if (showNotify) showNotify('Error al cargar datos de caja', 'error');
        } finally {
            setLoading(false);
        }
    }, [showNotify, loadMovements, branchId]);

    useEffect(() => {
        loadActiveShift();
    }, [loadActiveShift]);

    /**
     * Listener Realtime para actualizar movimientos cuando se agreguen nuevos
     */
    useEffect(() => {
        if (!activeShift) return;

        // Subscribe a cambios en cash_movements para este shift
        const channel = supabase
            .channel(`cash_movements:shift_id=eq.${activeShift.id}`)
            .on(
                'postgres_changes',
                {
                    event: '*', // Escuchar INSERT, UPDATE, DELETE
                    schema: 'public',
                    table: TABLES.cash_movements,
                    filter: `shift_id=eq.${activeShift.id}`
                },
                (payload) => {
                    if (payload.eventType === 'INSERT') {
                        // Re-fetchear para tener el mismo shape (con join orders) que loadMovements
                        loadMovements(activeShift.id);
                    } else if (payload.eventType === 'DELETE') {
                        // Remover si se borra
                        setMovements(prev => prev.filter(m => m.id !== payload.old.id));
                    } else if (payload.eventType === 'UPDATE') {
                        // Actualizar si cambia
                        setMovements(prev => prev.map(m => m.id === payload.new.id ? payload.new : m));
                    }
                }
            )
            .subscribe();

        return () => {
            channel.unsubscribe();
        };
    }, [activeShift, loadMovements]);

    /**
     * Abre un nuevo turno
     */
    const openShift = useCallback(async (amount) => {
        if (!branchId || branchId === 'all' || !isValidBranchId(branchId)) {
            if (showNotify) showNotify('Error: No se ha detectado la sucursal seleccionada.', 'error');
            return false;
        }
        try {
            const { data: newShift, error } = await supabase.rpc('cash_open_shift', {
                p_branch_id: branchId,
                p_opening_balance: Number(amount) || 0
            });

            if (error) throw error;

            setActiveShift(newShift);
            setMovements([]);
            if (showNotify) showNotify('Caja abierta con éxito');
            return true;
        } catch (error) {
            if (showNotify) {
                let msg = 'Error al abrir caja';
                if (error.message?.includes('Ya existe')) {
                    msg = error.message;
                } else if (error.code === '42501') {
                    msg = 'Error de permisos (RLS). Configura las políticas en Supabase.';
                }
                showNotify(msg, 'error');
            }
            return false;
        }
    }, [branchId, showNotify]);

    const getTotals = useCallback((movementsData = movements) => {
        return movementsData.reduce((acc, m) => {
            if (m.type === 'cancel') return acc;
            const amount = Number(m.amount) || 0;
            const order = m?.orders ?? null;
            const deliveryFee = Number(order?.delivery_fee) || 0;
            const desc = String(m?.description || '').toLowerCase();
            const isCourierPayout =
                m.type === 'expense' &&
                !order &&
                (desc.includes('delivery') || desc.includes('repartidor') || desc.includes('conductor'));

            if (m.type === 'expense') {
                acc.expenses += amount;
                if (isManualLocalExpense(m)) {
                    acc.manualExpenses += amount;
                    acc.manualExpenseCount += 1;
                    if (isCashWithdrawal(m)) {
                        acc.cashWithdrawals += amount;
                        acc.cashWithdrawalCount += 1;
                    } else if (isOperatingLocalExpense(m)) {
                        acc.operatingExpenses += amount;
                        acc.operatingExpenseCount += 1;
                    }
                } else {
                    acc.refundExpenses += amount;
                    acc.refundExpenseCount += 1;
                }
                if (m.payment_method === 'cash') acc.cash -= amount;
                else if (m.payment_method === 'card') acc.card -= amount;
                else if (m.payment_method === 'online') acc.online -= amount;

                if (deliveryFee > 0) {
                    acc.deliveryRefunded += deliveryFee;
                }
                if (isCourierPayout) {
                    acc.deliveryPaidToCourier += amount;
                }
                const refundOrderId = m.order_id ?? m.orderId;
                if (refundOrderId != null && String(refundOrderId).trim() !== '') {
                    acc.income -= amount;
                }
            } else {
                if (m.payment_method === 'cash') acc.cash += amount;
                else if (m.payment_method === 'card') acc.card += amount;
                else if (m.payment_method === 'online') acc.online += amount;
                acc.income += amount;

                if (m.type === 'sale' && deliveryFee > 0) {
                    acc.deliveryCollected += deliveryFee;
                }
            }
            return acc;
        }, {
            cash: 0,
            card: 0,
            online: 0,
            expenses: 0,
            manualExpenses: 0,
            manualExpenseCount: 0,
            cashWithdrawals: 0,
            cashWithdrawalCount: 0,
            operatingExpenses: 0,
            operatingExpenseCount: 0,
            refundExpenses: 0,
            refundExpenseCount: 0,
            income: 0,
            deliveryCollected: 0,
            deliveryRefunded: 0,
            deliveryPaidToCourier: 0,
        });
    }, [movements]);

    /**
     * Cierra el turno actual con cuadre por método.
     * @param {{ cash: number; card: number; online: number }} payload
     */
    const closeShift = useCallback(async (payload) => {
        if (!activeShift) return false;
        try {
            const totals = getTotals(movements);
            const expected = getExpectedByMethod(totals, activeShift);
            await cashService.closeShift(activeShift.id, {
                cash: Number(payload.cash),
                card: Number(payload.card),
                online: Number(payload.online),
                expectedCard: expected.card,
                expectedOnline: expected.online,
            });

            setActiveShift(null);
            setMovements([]);
            if (showNotify) showNotify('Caja cerrada correctamente');
            return true;
        } catch (err) {
            if (showNotify) {
                showNotify(err?.message || 'Error al cerrar caja', 'error');
            }
            return false;
        }
    }, [activeShift, movements, getTotals, showNotify]);

    /**
     * [MEJORA MULTI-NEGOCIO]
     * Obtiene el turno objetivo para una transacción.
     * Si estamos en vista "Todas", busca el turno abierto de la sucursal del pedido.
     */
    const getTargetShift = useCallback(async (orderBranchId) => {
        // 1. Escenario ideal: El turno activo en pantalla coincide con la orden
        if (activeShift && activeShift.branch_id === orderBranchId) {
            return activeShift;
        }

        // 2. Escenario Admin Global: Buscar turno abierto específico para esa sucursal
        if (orderBranchId) {
            const { data } = await supabase
                .from(TABLES.cash_shifts)
                .select('id, expected_balance, branch_id')
                .eq('status', 'open')
                .eq('branch_id', orderBranchId)
                .maybeSingle();
            return data;
        }
        return null;
    }, [activeShift]);

    /**
     * Agrega un movimiento manual (Ingreso/Egreso)
     */
    const addManualMovement = useCallback(async (type, amount, description, paymentMethod = 'cash', opts = {}) => {
        if (!activeShift) return false;
        try {
            const numericAmount = Number(amount);
            if (isNaN(numericAmount) || numericAmount <= 0) throw new Error("El monto debe ser un número mayor a 0");

            // Validación estricta para egresos
            if (type === 'expense' && (!description || description.trim().length < 3)) {
                throw new Error("Es obligatorio indicar el motivo del egreso (mínimo 3 letras).");
            }

            const expenseKind =
                type === 'expense' && opts?.expenseKind != null && String(opts.expenseKind).trim() !== ''
                    ? String(opts.expenseKind).trim()
                    : null;

            if (expenseKind === EXPENSE_KIND_CASH_WITHDRAWAL && paymentMethod !== 'cash') {
                throw new Error('Los retiros de efectivo solo pueden registrarse en efectivo.');
            }

            const rpcPayload = {
                p_shift_id: activeShift.id,
                p_type: type,
                p_amount: numericAmount,
                p_description: description,
                p_payment_method: paymentMethod,
                p_order_id: null,
            };
            if (expenseKind) {
                rpcPayload.p_expense_kind = expenseKind;
            }

            const { error } = await supabase.rpc('cash_add_movement', rpcPayload);
            if (error) throw error;
            
            await loadActiveShift();
            if (showNotify) {
                const custom = opts && typeof opts.successMessage === 'string' && opts.successMessage.trim() !== '';
                showNotify(
                    custom
                        ? opts.successMessage.trim()
                        : type === 'income'
                          ? 'Ingreso registrado'
                          : 'Egreso registrado'
                );
            }
            return true;
        } catch (error) {
            if (showNotify) {
                if (error.code === '42501') {
                    showNotify('Error de permisos (RLS) al registrar movimiento.', 'error');
                } else {
                    showNotify(error.message || 'Error al registrar movimiento', 'error');
                }
            }
            return false;
        }
    }, [activeShift, showNotify, loadActiveShift]);

    /**
     * Registra una venta automáticamente
     */
    const registerSale = useCallback(async (order) => {
        // [ROBUSTEZ] Usar getTargetShift en lugar de depender solo de activeShift
        const targetShift = await getTargetShift(order.branch_id);
        if (!targetShift) {
            if (showNotify) showNotify('No hay caja abierta para esta sucursal', 'error');
            return false;
        }

        try {
            // [MEJORA ROBUSTEZ] Verificar balance neto de la orden en este turno
            // Esto permite manejar casos de: Venta -> Cancelación -> Venta (Re-ingreso)
            const { data: movements } = await supabase
                .from(TABLES.cash_movements)
                .select('type, amount, payment_method')
                .eq('shift_id', targetShift.id)
                .eq('order_id', order.id);

            const saleAmount = Math.round(Number(order.total) || 0);
            if (saleAmount <= 0) return false; // No registrar ventas de valor 0 o inválidas

            const currentNet = (movements || []).reduce(
                (acc, m) => acc + (m.type === 'sale' ? Number(m.amount) || 0 : -(Number(m.amount) || 0)),
                0,
            );

            // Si el balance neto ya es igual al total (o muy cercano), ya está registrada.
            if (Math.abs(currentNet - saleAmount) < 5) return true;

            const movement = {
                shift_id: targetShift.id,
                type: 'sale',
                amount: saleAmount,
                description: `Venta #${String(order.id).slice(-4)} - ${order.client_name}`,
                payment_method: getCashMovementPaymentMethod(order, movements || []),
                order_id: order.id
            };

            const { error } = await supabase.rpc('cash_add_movement', {
                p_shift_id: movement.shift_id,
                p_type: movement.type,
                p_amount: movement.amount,
                p_description: movement.description,
                p_payment_method: movement.payment_method,
                p_order_id: movement.order_id
            });
            if (error) throw error;

            // Solo recargar si el turno afectado es el que estamos viendo
            if (activeShift && activeShift.id === targetShift.id) {
                await loadActiveShift();
            }
            return true;
        } catch {
            if (showNotify) showNotify('Error registrando venta en caja', 'error');
            return false;
        }
    }, [activeShift, loadActiveShift, getTargetShift, showNotify]);

    /**
     * Registra una devolución
     */
    const registerRefund = useCallback(async (order) => {
        // [ROBUSTEZ] Usar getTargetShift para devoluciones también
        const targetShift = await getTargetShift(order.branch_id);
        if (!targetShift) {
            if (showNotify) showNotify('No hay caja abierta para esta sucursal', 'error');
            return false;
        }

        try {
            // [MEJORA ROBUSTEZ] Verificar si ya está reembolsada (Neto ~ 0)
            const { data: movements } = await supabase
                .from(TABLES.cash_movements)
                .select('type, amount, payment_method')
                .eq('shift_id', targetShift.id)
                .eq('order_id', order.id);

            const currentNet = (movements || []).reduce(
                (acc, m) => acc + (m.type === 'sale' ? Number(m.amount) || 0 : -(Number(m.amount) || 0)),
                0,
            );

            // Si el balance neto es 0 (o negativo), ya está reembolsada o nunca se cobró.
            if (currentNet <= 5) return true;

            const refundAmount = Math.round(currentNet);
            if (refundAmount <= 0) return true;

            const movement = {
                shift_id: targetShift.id,
                type: 'expense',
                amount: refundAmount,
                description: `Devolución #${String(order.id).slice(-4)} - ${order.client_name}`,
                payment_method: getCashMovementPaymentMethod(order, movements || []),
                order_id: order.id
            };

            const { error } = await supabase.rpc('cash_add_movement', {
                p_shift_id: movement.shift_id,
                p_type: movement.type,
                p_amount: movement.amount,
                p_description: movement.description,
                p_payment_method: movement.payment_method,
                p_order_id: movement.order_id
            });
            if (error) throw error;

            if (activeShift && activeShift.id === targetShift.id) {
                await loadActiveShift();
            }
            if (showNotify) showNotify('Devolución registrada en caja', 'success');
            return true;
        } catch {
            if (showNotify) showNotify('Error registrando devolución', 'error');
            return false;
        }
    }, [activeShift, showNotify, loadActiveShift, getTargetShift]);

    const getPastShifts = useCallback(async (limit = 20) => {
        if (!branchId || !isValidBranchId(branchId)) return [];
        const { data, error } = await supabase
            .from(TABLES.cash_shifts)
            .select(`
                *,
                cash_movements (
                    amount,
                    type,
                    payment_method
                ),
                orders(count)
            `)
            .eq('status', 'closed')
            .eq('branch_id', branchId) // FILTRO POR SUCURSAL
            .neq('orders.status', 'cancelled') // Excluir pedidos cancelados/devueltos del conteo del turno
            .order('closed_at', { ascending: false })
            .limit(limit);
        if (error) throw error;
        
        // Calcular totales de transferencias y conteo de pedidos para cada turno
        const result = data.map(shift => {
            const movements = shift.cash_movements || [];
            const totalOnline = movements
                .filter(m => m.payment_method === 'online' && m.type === 'sale')
                .reduce((sum, m) => sum + (Number(m.amount) || 0), 0);
            const ordersCount = Array.isArray(shift.orders)
                ? Number(shift.orders[0]?.count ?? 0)
                : 0;

            return { ...shift, total_online: totalOnline, orders_count: ordersCount };
        });

        return result;
    }, [branchId]);

    const getShiftMovements = useCallback(async (shiftId) => {
        return cashService.getShiftMovements(shiftId);
    }, []);

    // Memoizar el objeto de retorno para evitar re-renderizados infinitos en consumidores
    return useMemo(() => ({
        activeShift,
        loading,
        movements,
        loadingMovements,
        openShift,
        closeShift,
        addManualMovement,
        registerSale,
        registerRefund,
        refresh: loadActiveShift,
        getPastShifts,
        getShiftMovements,
        getTotals
    }), [
        activeShift, loading, movements, loadingMovements,
        openShift, closeShift, addManualMovement, registerSale, registerRefund,
        loadActiveShift, getPastShifts, getShiftMovements, getTotals
    ]);
};
